#!/bin/bash

git pull &&
source ./bin/activate &&

flask run
