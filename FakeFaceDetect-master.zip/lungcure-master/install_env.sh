#!/bin/bash

git pull &&

pip3 install -r requirements.txt
